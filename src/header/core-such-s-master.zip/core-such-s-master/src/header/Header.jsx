import './header.css'
import { truncateCart } from '../slices/listsSlice';
import {useState} from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom'
import {delCart} from '../slices/listsSlice'
import { useForm } from 'react-hook-form';
import Mastercard from './mastercard.svg'
import Visa from './visa.svg'
import Mir from './mir.svg'
export const Header = () => {
    const dispatch = useDispatch();
    const { register, reset, handleSubmit, formState: { errors } } = useForm();
    const [checkout, openCheckout] = useState("hide");
    const [menu, setMenu] = useState(window.innerWidth<=1000?"-100%":"-600px");
    const [cartmenu, setCartMenu] = useState(window.innerWidth<=1000?"-100%":"-600px");
    const [rotate, setRotation] = useState(0);
    const cart = useSelector(state => state.cart.cart);

    
    const cartSumm = () => {
        let cartsum = 0;
        cart.map((elem) => {
            cartsum += parseFloat(elem.price);
            return null;
        })
        return cartsum;
    }
    var cartsum = cartSumm();
    window.onresize = () => {
        var wth = window.innerWidth;
        var slide;
        wth<=1000?slide="-100%":slide="-600px";
        setMenu(slide);
        setCartMenu(slide);
        document.getElementsByClassName("header__burger")[0].style.fill = "";
        document.getElementsByClassName("header__cart")[0].style.fill = "";
    }
    async function handleEmail(data) {
      console.log("Sending email with data:", data); 
      try {
        const response = await fetch('http://localhost:5000/send-email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(
              { 
                  email: data.email,
                  subject: "Спасибо за покупку!",
                  message: `Привет, ${data.cardHolder}! 
                  Спасибо за вашу покупку в нашем магазине.
                  ${cart.map((elem) => {
                    return `${elem.title} - ${elem.price}`
                  })}
                  Если вы ничего не заказывали, и вам пришло это сообщение, свяжитесь с нами.
                  Ваш магазин пластинок, Septima.`
              }
          )
        });
        const result = await response.json();
        alert(result.message);
      } catch (error) {
        console.error('Error in handleEmail:', error);
        alert('Failed to send email');
      }
    }
    const onSubmit = (data) => {
        console.log("Данные карты:", data);
        handleEmail(data)
        alert('Успешно!')
        openCheckout("hide")
        dispatch(truncateCart())
        reset();
      };
    const menuOpen = () => {
        var wth = window.innerWidth;
        var slide;
        wth<=1000?slide="-100%":slide="-600px";
        setTimeout(() => {        setRotation(rotate + 180)}, 100)
        if(menu==="0%") {
            setMenu(slide)
            document.getElementsByClassName("header__burger")[0].style.fill = "";
            
        }
        else {
            document.getElementsByClassName("header__burger")[0].style.fill = "#6CABD9";
            setMenu("0%");
            setCartMenu(slide)
            document.getElementsByClassName("header__cart")[0].style.fill = "";
        }
    }
    const cartmenuOpen = () => {
        var wth = window.innerWidth;
        var slide;
        wth<=1000?slide="-100%":slide="-600px";
        if(cartmenu==="0%") {
            setCartMenu(slide)
            document.getElementsByClassName("header__cart")[0].style.fill = "";
            
        }
        else {
            document.getElementsByClassName("header__cart")[0].style.fill = "#6CABD9";
            setCartMenu("0%");
            setMenu(slide);
            document.getElementsByClassName("header__burger")[0].style.fill = "";
        }
    }
    return <div className="header">
        <div className="header__checkoutwindow" id={checkout}>
            <div className="checkout__window">
            <div id="close" onClick={() => {openCheckout("hide")}}>X</div>
            <div className="checkout__content">
                <p>Итого к оплате: {cartsum.toPrecision(3)}$</p>
                <form onSubmit={handleSubmit(onSubmit)}>
                <div>
          <label>E-mail</label>
          <input
            type="email"
            placeholder="Введите email"
            {...register("email", {
              required: "Введите email",
              pattern: {
                value: /^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/,
                message: "Введиье корректный email"
              }
            })}
          />
          <br/>
          {errors.email && <font>{errors.email.message}</font>}
        </div>
        <div>
          <label>Номер карты</label>
          <input
            type="text"
            placeholder="XXXXXXXXXXXXXXXX"
            {...register("cardNumber", {
              required: "Введите номер карты",
              pattern: {
                value: /^[0-9]{16}$/,
                message: "Номер карты должен содержать 16 цифр"
              }
            })}
          />
          <br/>
          {errors.cardNumber && <font>{errors.cardNumber.message}</font>}
        </div>

        <div>
          <label>Срок действия</label>
          <input
            type="text"
            placeholder="MM/YY"
            {...register("expiryDate", {
              required: "Введите срок действия",
              pattern: {
                value: /^(0[1-9]|1[0-2])\/\d{2}$/,
                message: "Введите срок в формате MM/YY"
              }
            })}
          />
          <br/>
          {errors.expiryDate && <font>{errors.expiryDate.message}</font>}
        </div>

        <div>
          <label>CVV</label>
          <input
            type="password"
            placeholder="123"
            {...register("cvv", {
              required: "Введите CVV",
              pattern: {
                value: /^[0-9]{3,4}$/,
                message: "CVV должен содержать 3 или 4 цифры"
              }
            })}
          />
          <br/>
          {errors.cvv && <font>{errors.cvv.message}</font>}
        </div>

        <div>
          <label>Имя владельца карты</label>
          <input
            type="text"
            placeholder="PETR IVANOV"
            {...register("cardHolder", {
              required: "Введите имя владельца",
              minLength: {
                value: 2,
                message: "Имя должно содержать не менее 2 символов"
              }
            })}
          />
          <br/>
          {errors.cardHolder && <font>{errors.cardHolder.message}</font>}
        </div>

        <button type="submit">Оплатить</button>
      </form>
            </div>
            <div className="checkout__payments">
                <img alt="visa" height="50" src={Visa}/>
                <img alt="mastercard" height="50" src={Mastercard}/>
                <img alt="mir" height="50" src={Mir}/>
            </div>
                
            </div>
        </div>
        <div className="header__burger" onClick={menuOpen} style={{ transform: `rotate(${rotate + "deg"})` }}>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M10 10H3V4a1 1 0 0 1 1-1h6zm11-6a1 1 0 0 0-1-1h-6v7h7zM4 21h6v-7H3v6a1 1 0 0 0 1 1zm17-1v-6h-7v7h6a1 1 0 0 0 1-1z"/></svg>
        </div>
        <div className="header__logo">
        <Link to='core-such-s' className='link'><p>Septima</p></Link>
        </div>
        <div className="header__cart" onClick={cartmenuOpen} onTo={cartmenuOpen}>
        <svg xmlns="http://www.w3.org/2000/svg" width="60" height="50.4" viewBox="0 0 1024 1024" id="cart">
  <path d="M63.2 161h164.7c-9.6-7.3-19.3-14.7-28.9-22 4.8 14.6 9.6 29.2 14.4 43.9 11.6 35.1 23.1 70.2 34.7 105.3C262 330.4 276 372.7 289.9 415c12.1 36.7 24.2 73.4 36.2 110.1 5.9 17.8 11.5 35.7 17.6 53.4.1.3.2.5.3.8 4.9 14.9 21 26.1 36.9 21 14.8-4.8 26.2-20.9 21-36.9-4.8-14.6-9.6-29.2-14.4-43.9-11.6-35.1-23.1-70.2-34.7-105.3-13.9-42.3-27.8-84.6-41.8-126.9-12.1-36.7-24.2-73.4-36.2-110.1-5.9-17.8-11.4-35.7-17.6-53.4-.1-.3-.2-.5-.3-.8-4.2-12.6-15.3-22-28.9-22H63.3c-15.7 0-30.7 13.8-30 30 .6 16.3 13.1 30 29.9 30z"></path>
  <path d="M347 556.1c-16.2 28.9-32.5 57.7-48.7 86.6-2.3 4.2-4.7 8.3-7 12.5-11.1 19.7 2.9 45.1 25.9 45.1h458c21.1 0 42.3.4 63.5 0h.9c15.7 0 30.7-13.8 30-30-.7-16.3-13.2-30-30-30h-458c-21.1 0-42.4-.6-63.5 0h-.9c8.6 15 17.3 30.1 25.9 45.1 16.2-28.9 32.5-57.7 48.7-86.6 2.3-4.2 4.7-8.3 7-12.5 7.7-13.7 3.7-33.4-10.8-41-14.2-7.4-32.8-3.8-41 10.8z"></path>
  <circle cx="746.5" cy="824.9" r="68.1"></circle>
  <path d="M658.4 824.9c.4 37.5 23.9 69.9 58.8 83 33 12.4 73.6 1.6 96.1-25.6 23.9-29 28.7-70.3 8.8-102.9-19.6-32.2-57.2-47.9-93.9-40.7-40.5 7.9-69.4 45.6-69.8 86.2-.1 10.5 9.3 20.5 20 20 10.9-.5 19.9-8.8 20-20 0-1.6.1-3.3.2-4.9 0-.7.1-1.4.2-2.1.3-4-.1 1.3-.2 1.2-.7-.4 2.1-9 2.4-9.8.3-.8.9-4.2 1.6-4.4.2-.1-1.8 3.7-.7 1.7.4-.8.8-1.6 1.1-2.4 1.5-3 3.3-5.7 5.1-8.5 1.9-2.9-2.7 3.1.5-.6 1-1.1 2-2.3 3.1-3.4s2.2-2.2 3.3-3.2c.5-.4 1-.9 1.5-1.3.7-.6 3.6-2 1-.9-2.2.9-.6.5.1 0s1.4-1 2.2-1.5c1.1-.7 2.2-1.4 3.4-2 1.5-.9 3.1-1.6 4.7-2.4.5-.3 2.6-1.3 0-.1-3 1.4 1-.3 1.3-.4 2.7-1 5.6-1.8 8.4-2.4.9-.2 1.8-.3 2.7-.5 2.2-.5-1.9.2-1.9.2 1.8 0 3.7-.4 5.5-.4 3.3-.1 6.5 0 9.8.3 3.7.3-3.8-.7.8.2 1.8.3 3.5.8 5.3 1.2 1.5.4 3 .9 4.5 1.4.4.1 2.4.8 2.5.9.1.3-3.7-1.9-1.7-.7 2.8 1.7 5.9 3 8.7 4.8.7.5 1.4 1 2.2 1.5.7.5 2.2.9.1 0-2-.8-.7-.6 0 .1.7.6 1.3 1.1 2 1.7 2.5 2.2 4.6 4.6 6.8 7 3 3.3-1.4-2.3.5.6.8 1.3 1.7 2.5 2.5 3.8.8 1.3 1.6 2.7 2.3 4l.9 1.8c1.9 3.6.4-.3-.1-.5 1.2.4 2.5 7.6 2.9 8.9.3 1.3.6 2.7.9 4 .8 3.8-.1-1.2-.1-1.3.5.5.3 2.8.3 3.4.2 3 .2 6.1 0 9.1-.1.9-.2 1.8-.2 2.8-.1 2-1.2 1.7.2-1.2-.7 1.5-.7 3.7-1.1 5.3-.7 2.8-1.8 5.5-2.6 8.3-.8 2.5 1.8-3.4.5-1.1-.3.5-.6 1.2-.8 1.8-.8 1.6-1.6 3.1-2.5 4.6-.8 1.3-1.6 2.6-2.5 3.9-2.7 4.1 1.9-2-.4.7-2.2 2.5-4.3 4.9-6.8 7.1-.4.4-2.8 3-3.5 3 0 0 4.1-2.8.9-.8-.6.4-1.1.7-1.6 1.1-2.8 1.8-5.7 3.3-8.6 4.8-3.1 1.6 3.6-1.2-.7.3-1.5.5-2.9 1-4.4 1.5-1.5.4-3 .8-4.6 1.2-.7.1-1.3.3-2 .4-4.4 1 3.2-.2.6 0-3.3.3-6.5.5-9.8.4-1.6 0-3.2-.2-4.9-.3-.6 0-3-.3-.1 0 3.3.3-.7-.2-1.4-.3-3.5-.7-6.9-1.8-10.3-3-.6-.2-2.6-1.2-.1 0 2.9 1.4-.6-.3-1.2-.6-1.6-.8-3.1-1.6-4.6-2.5-1.5-.9-2.9-1.9-4.4-2.9-2.4-1.5.3.8.9.8-.4 0-1.7-1.4-2-1.7-2.6-2.3-5.1-4.7-7.4-7.4 0 0-1.7-1.7-1.7-2 0 .4 2.4 3.4.8.9-1-1.5-2-2.9-2.9-4.4-1-1.7-1.9-3.5-2.8-5.2-2.1-4.1 1 3.2-.6-1.3-1.2-3.4-2.2-6.8-2.9-10.4-.1-.6-.1-1.5-.4-2 1.5 3.3.3 2.8.1.5-.2-2.1-.3-4.2-.3-6.3-.1-10.5-9.1-20.5-20-20-11.2.3-20.6 8.7-20.5 19.9z"></path>
  <circle cx="401.8" cy="824.9" r="68.1"></circle>
  <path d="M313.7 824.9c.4 37.5 23.9 69.9 58.8 83 33 12.4 73.6 1.6 96.1-25.6 23.9-29 28.7-70.3 8.8-102.9-19.6-32.2-57.2-47.9-93.9-40.7-40.6 7.9-69.4 45.6-69.8 86.2-.1 10.5 9.3 20.5 20 20 10.9-.5 19.9-8.8 20-20 0-1.6.1-3.3.2-4.9 0-.7.1-1.4.2-2.1.3-4-.1 1.3-.2 1.2-.7-.4 2.1-9 2.4-9.8.3-.8.9-4.2 1.6-4.4.2-.1-1.8 3.7-.7 1.7.4-.8.8-1.6 1.1-2.4 1.5-3 3.3-5.7 5.1-8.5 1.9-2.9-2.7 3.1.5-.6 1-1.1 2-2.3 3.1-3.4s2.2-2.2 3.3-3.2c.5-.4 1-.9 1.5-1.3.7-.6 3.6-2 1-.9-2.2.9-.6.5.1 0s1.4-1 2.2-1.5c1.1-.7 2.2-1.4 3.4-2 1.5-.9 3.1-1.6 4.7-2.4.5-.3 2.6-1.3 0-.1-3 1.4 1-.3 1.3-.4 2.7-1 5.6-1.8 8.4-2.4.9-.2 1.8-.3 2.7-.5 2.2-.5-1.9.2-1.9.2 1.8 0 3.7-.4 5.5-.4 3.3-.1 6.5 0 9.8.3 3.7.3-3.8-.7.8.2 1.8.3 3.5.8 5.3 1.2 1.5.4 3 .9 4.5 1.4.4.1 2.4.8 2.5.9.1.3-3.7-1.9-1.7-.7 2.8 1.7 5.9 3 8.7 4.8.7.5 1.4 1 2.2 1.5.7.5 2.2.9.1 0-2-.8-.7-.6 0 .1.7.6 1.3 1.1 2 1.7 2.5 2.2 4.6 4.6 6.8 7 3 3.3-1.4-2.3.5.6.8 1.3 1.7 2.5 2.5 3.8.8 1.3 1.6 2.7 2.3 4l.9 1.8c1.9 3.6.4-.3-.1-.5 1.2.4 2.5 7.6 2.9 8.9.3 1.3.6 2.7.9 4 .8 3.8-.1-1.2-.1-1.3.5.5.3 2.8.3 3.4.2 3 .2 6.1 0 9.1-.1.9-.2 1.8-.2 2.8-.1 2-1.2 1.7.2-1.2-.7 1.5-.7 3.7-1.1 5.3-.7 2.8-1.8 5.5-2.6 8.3-.8 2.5 1.8-3.4.5-1.1-.3.5-.6 1.2-.8 1.8-.8 1.6-1.6 3.1-2.5 4.6-.8 1.3-1.6 2.6-2.5 3.9-2.7 4.1 1.9-2-.4.7-2.2 2.5-4.3 4.9-6.8 7.1-.4.4-2.8 3-3.5 3 0 0 4.1-2.8.9-.8-.6.4-1.1.7-1.6 1.1-2.8 1.8-5.7 3.3-8.6 4.8-3.1 1.6 3.6-1.2-.7.3-1.5.5-2.9 1-4.4 1.5-1.5.4-3 .8-4.6 1.2-.7.1-1.3.3-2 .4-4.4 1 3.2-.2.6 0-3.3.3-6.5.5-9.8.4-1.6 0-3.2-.2-4.9-.3-.6 0-3-.3-.1 0 3.3.3-.7-.2-1.4-.3-3.5-.7-6.9-1.8-10.3-3-.6-.2-2.6-1.2-.1 0 2.9 1.4-.6-.3-1.2-.6-1.6-.8-3.1-1.6-4.6-2.5-1.5-.9-2.9-1.9-4.4-2.9-2.4-1.5.3.8.9.8-.4 0-1.7-1.4-2-1.7-2.6-2.3-5.1-4.7-7.4-7.4 0 0-1.7-1.7-1.7-2 0 .4 2.4 3.4.8.9-1-1.5-2-2.9-2.9-4.4-1-1.7-1.9-3.5-2.8-5.2-2.1-4.1 1 3.2-.6-1.3-1.2-3.4-2.2-6.8-2.9-10.4-.1-.6-.1-1.5-.4-2 1.5 3.3.3 2.8.1.5-.2-2.1-.3-4.2-.3-6.3-.1-10.5-9.1-20.5-20-20-11.3.3-20.7 8.7-20.5 19.9zM960.8 258 839.4 571H372.9L269.7 258z"></path>
  <path d="M941.5 252.5c-13.7 35.3-27.3 70.6-41 105.9-21.8 56.3-43.6 112.5-65.3 168.8-5 12.9-10 25.9-15 38.8 6.4-4.9 12.9-9.8 19.3-14.7H430.4c-18.8 0-37.8-.8-56.7 0h-.8c6.4 4.9 12.9 9.8 19.3 14.7-11.7-35.5-23.3-70.9-35-106.4-18.5-56.1-37-112.2-55.4-168.4-4.3-12.9-8.5-25.8-12.8-38.8-6.4 8.4-12.9 16.9-19.3 25.3H932.8c9 0 18 .2 26.9 0h1.2c10.5 0 20.5-9.2 20-20s-8.8-20-20-20H297.8c-9 0-18-.2-26.9 0h-1.2c-12.5 0-23.4 12.9-19.3 25.3 11.7 35.5 23.3 70.9 35 106.4 18.5 56.1 37 112.2 55.4 168.4 4.3 12.9 8.5 25.8 12.8 38.8 2.8 8.4 10.2 14.7 19.3 14.7H782c18.8 0 37.8.7 56.7 0h.8c9.5 0 16.1-6.4 19.3-14.7 13.7-35.3 27.3-70.6 41-105.9 21.8-56.3 43.6-112.5 65.3-168.8 5-12.9 10-25.9 15-38.8 3.8-9.8-4.2-22.4-14-24.6-11.5-2.6-20.6 3.5-24.6 14z"></path>
</svg></div>
        <div className="header__menu" style={{left: menu}}>
        <Link to="core-such-s"><div className="header__main" id="mainpage" onClick={menuOpen}>Главная</div></Link>
        <Link to="catalog"><div className="header__main" onClick={menuOpen}>Каталог</div></Link>
        <Link to="about"><div className="header__main" onClick={menuOpen}>О нас</div></Link>
        <span className="header__grad"></span>
        </div>
        <div className="header__cartmenu" style={{right: cartmenu}}>
            <div className="header__cartcontent">
                {cart.map((elem) => {
                    return <div className='header__cartelement'>
                        <img alt="minialbum" src={elem.imageUrl} style={{width: "100px", height: "100px"}}/>
                        <div style={{display: "flex", flexDirection: "column", textAlign: "start", marginLeft: "15px"}}>
                        <h1 style={{fontSize: "26px"}}>{elem.title}</h1>
                        <h2>{elem.price}$</h2>
                        <button id="delete" onClick={() => {dispatch(delCart(elem.title))}}>x</button>
                        </div>
                    </div>
                })}
            </div>
            <div className='header__checkout'>
                <hr/>
                <p>Итого: {cartsum.toPrecision(4)}$</p>
                <button onClick={() => {
                  if(parseInt(cartsum) === 0) {
                    alert("Ваша корзина пуста!");
                  }
                  else {
                  openCheckout("show")
                }
                  
                  }}>Перейти к оформлению</button>
            </div>
        </div>
    </div>
}

