# core-such-s 1.0

This project is powered by React

## About this proejct
This is course project for Scripted Programming Language discipline

